<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<form method="post" actioin="teste.php">
<input type="text" name="nome"><br      >
<input type="email" name="email"><br> 
<input type="submit" name="excluir"value="Excluir Registros"/>
<input type="submit" name="alterar"value="Alterar Registros"/>
</form>  
</body>
</html>
