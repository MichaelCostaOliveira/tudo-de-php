<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php for ($x=0;$x<=1000;$x++){?>

    <hr>
    <div style="width:50px; height:50px; border:1px solid green;"><?=$x?></div>

    <?php } ?>


</body>
</html>