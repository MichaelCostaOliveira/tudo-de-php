<?php

require 'lib/funcoes.php';
var_dump($_POST);
$post = limpa_post($_POST);
var_dump($post);