<?php
require 'cliente.php';

$cliente = new Impacta\Cliente;