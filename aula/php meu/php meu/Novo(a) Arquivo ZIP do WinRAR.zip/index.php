<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<?php
    echo "ola mundo<br/>";

    $empresa = "impacta tecnologia";

    echo "<h1>A empresa citada é " . $empresa . "</h1>";

    //comentario
    #comentario de uma linha
    /* */

    // delimitadores php
?>
    <!--delimitador não mais ultilizado-->
    <script language="php">
        echo "ola";
        </script>

    <!--delimitador SHORT_OPEN_TAG HABILITAR no php.ini-->

    <?
        echo"<br/>Digite seu Nome:<input type='text'";
        //phpinfo();
    ?>    

    <!-- delimitador php depreciado <% %>  -->
</body>
</html>