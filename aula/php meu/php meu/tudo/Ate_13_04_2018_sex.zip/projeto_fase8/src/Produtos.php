<?php
namespace Impacta;

class Produtos
{
    public function getAll()
    {
        // Implementar com banco de dados
    }
}