<?php

$letras = array('A','B','C','D','E');

shuffle($letras);
print_r($letras);
echo '<br/>';
var_dump($letras);

shuffle($letras);
print_r($letras);
echo '<br/>';
var_dump($letras);

shuffle($letras);
print_r($letras);
echo '<br/>';
var_dump($letras);
?>


